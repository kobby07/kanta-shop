from django.urls import path



# urlpatterns = [
#     path('', views.Register, name='users_signup'),
    
# ]